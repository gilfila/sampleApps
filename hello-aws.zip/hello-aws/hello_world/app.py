
# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""
Purpose
An AWS lambda function that checks if the current day matches a specific week of the month and day of the week.
"""
import json
import logging
from datetime import datetime, date

# Set up logging.
logger = logging.getLogger(__name__)


def lambda_handler(event, context):
    """
    Checks if the current day matches the specified week of the month and day of the week.
    
    Args:
        event: Dictionary containing:
            - week_of_month: Integer (1-5) representing which week of the month
            - day_of_week: Integer (0-6) where Monday=0, Sunday=6
    
    Returns:
        Boolean: True if current day matches, False otherwise
    """
    # Logging of arguments
    logger.info("event: %s", str(event))
    logger.info("context: %s", str(context))
    
    try:
        # Get inputs from event
        week_of_month = int(event.get('week_of_month'))
        day_of_week = int(event.get('day_of_week'))
        
        # Get current date
        today = date.today()
        current_day_of_week = today.weekday()  # Monday=0, Sunday=6
        
        # Calculate which week of the month today falls in
        # Get the first day of the month
        first_day_of_month = date(today.year, today.month, 1)
        first_day_weekday = first_day_of_month.weekday()
        
        # Calculate the day of month (1-based)
        day_of_month = today.day
        
        # Calculate which week of the month this day falls in
        # Formula: (day_of_month - 1 + first_day_weekday) // 7 + 1
        current_week_of_month = ((day_of_month - 1 + first_day_weekday) // 7) + 1
        
        # Check if current day matches the specified week and day
        matches = (current_week_of_month == week_of_month and 
                  current_day_of_week == day_of_week)
        
        logger.info("Today: %s, Week of month: %d, Day of week: %d", 
                   today, current_week_of_month, current_day_of_week)
        logger.info("Input - Week of month: %d, Day of week: %d, Matches: %s",
                   week_of_month, day_of_week, matches)
        
        return matches
        
    except (KeyError, ValueError, TypeError) as e:
        logger.error("Error processing event: %s", str(e))
        return False